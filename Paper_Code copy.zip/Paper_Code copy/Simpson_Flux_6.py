import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import simpson as simps,quad
from scipy.interpolate import interp1d

def N_GCE (E): 
  constant = 8.6*10**14
  parentheses = E
  exponent = 0.27-(0.27*np.log10(E))
  return constant*(parentheses**exponent)

lower_N_GCE_limit = 1
upper_N_GCE_limit = 100

result_N_GCE, error_N_GCE = quad(N_GCE, lower_N_GCE_limit,upper_N_GCE_limit)

djdvr = np.loadtxt('E_C_Cusp_Total_Data.txt', delimiter = '\t', skiprows=1)

radial_data = djdvr[:, 0]
annihilation_data = djdvr[:, 1]

d = 803
angle = np.linspace(0,14,80)

result_annihilation= np.zeros(80)
error_annihilation= np.zeros(80)

theta = np.linspace(0,0.244346095,80)
r_200 = np.linspace(0,213,80)

line_of_sight = np.sqrt((r_200**2) - (d*np.sin(theta))**2)
los_val = np.linspace(0,87.35432036,80)

djdvl_function = interp1d(line_of_sight, annihilation_data, kind = 'linear', fill_value = 'extrapolate') # dJ/dV(L)

# print(djdvl_function(los_val)) # Need to use all 80 values of djdvl_function(los_val)to plug into integral.

yaxis = 2*djdvl_function(los_val)*213

# plt.xlim(1.3, 15)
# plt.ylim(1.3*10**-10,0.4)
plt.xscale('log')
plt.yscale('log')
plt.plot(angle,yaxis)
plt.show()


























# for i,r in enumerate(angle):

#   lower_limit = 0.000001
#   upper_limit = 213

#   result_annihilation[i], error_annihilation[i] = quad(djdvl_function, lower_limit, upper_limit)




































